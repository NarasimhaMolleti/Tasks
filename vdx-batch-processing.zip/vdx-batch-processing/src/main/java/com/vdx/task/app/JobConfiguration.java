package com.vdx.task.app;

import java.util.Arrays;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.support.ListItemReader;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.vdx.task.app.utils.BatchProcessingUtils;
import com.vdx.task.beans.Student;

@Configuration
class JobConfiguration {
	private final JobBuilderFactory jobBuilderFactory;
	private final StepBuilderFactory stepBuilderFactory;

	public JobConfiguration(JobBuilderFactory jobBuilderFactory,
			StepBuilderFactory stepBuilderFactory) {
		this.jobBuilderFactory = jobBuilderFactory;
		this.stepBuilderFactory = stepBuilderFactory;
	}
	
	@Bean
	Job readAndWriteToDbJob() {
		return this.jobBuilderFactory.get("readFromExtAndWriteToDb").incrementer(new RunIdIncrementer())
				.start(readFromExternalStorage()).next(writeToDatabase()).build();
	}

	@Bean
	Step readFromExternalStorage() {
		return stepBuilderFactory.get("readFromExternalStorage").<Student, Student> chunk(9)
				.reader(BatchProcessingUtils.reader())
				.writer(items -> {
					for (Student item : items) {
						System.out.println(item.getName());
					}
				}).build();
	}
	
	@Bean
	Step writeToDatabase() {
		return stepBuilderFactory.get("writeToFile").<String, String> chunk(3)
				.reader(new ListItemReader<>(Arrays.asList("Writing to Db","Writing to Db")))
				.processor(item -> item)
				.writer(items -> {
					for (String item : items) {
						System.out.println(">> " + item);
					}
				}).build();
	}
	
	
	//To be Scrapped
//	public List<Student> getAllStudents(){
//		int i = 1;
//		List<Student> students = new ArrayList<Student>();
//		while(i<10) {
//			Student student = new Student();
//			student.setId(i);
//			student.setMarks(i*10);
//			student.setRank(i);
//			student.setName("student"+i);
//			students.add(student);
//		}
//		return students;
//		
//	}


}
