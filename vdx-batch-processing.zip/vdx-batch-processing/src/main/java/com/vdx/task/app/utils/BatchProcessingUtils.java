package com.vdx.task.app.utils;

import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.FileSystemResource;

import com.vdx.task.beans.Student;

public  class BatchProcessingUtils {

	@Bean
	public static FlatFileItemReader<Student> reader() 
	{
	    FlatFileItemReader<Student> reader = new FlatFileItemReader<Student>();
	    reader.setResource(new FileSystemResource("src/main/resources/students.csv"));
	    reader.setLinesToSkip(1);   
	    reader.setLineMapper(new DefaultLineMapper<Student>() {
	        {
	            setLineTokenizer(new DelimitedLineTokenizer() {
	                {
	                    setNames(new String[] { "id", "name", "marks", "rank" });
	                }
	            });
	            setFieldSetMapper(new BeanWrapperFieldSetMapper<Student>() {
	                {
	                    setTargetType(Student.class);
	                }
	            });
	        }
	    });
	    return reader;
	}
	
}
