### Build

```
$ ./mvnw clean package -DskipTests=true
```

### Run main class as Java Application - SpringBatchDemoApplication


```

